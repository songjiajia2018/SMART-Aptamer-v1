#!/usr/bin/Rscript
args<-commandArgs(T)
cquan=as.numeric(args[1])
a=args[2]
a=read.table(a)
b=args[3]
rounds=a$V1
file=paste(b,'/',"kmer.pdf",sep='');
pdf(file=file)
par(mfrow=c(3,2))
for( round in rounds){
	file=paste(b,'/',round,"_kmer.txt",sep='')
	data=read.table(file)
	data$V2=data$V2/sum(data$V2)
	hist(data$V2,breaks=300,xlab=round)
	file=paste(b,'/',round,"_kmer_percent.txt",sep='');
	q95=quantile(data$V2,cquan)
	q95_info=paste(round,q95,sep='    ');
	print(q95_info)
	write.table(data,file=file)
}
dev.off()
